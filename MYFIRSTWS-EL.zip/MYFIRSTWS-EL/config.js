var secret='s12xyz00';


module.exports.key=secret;